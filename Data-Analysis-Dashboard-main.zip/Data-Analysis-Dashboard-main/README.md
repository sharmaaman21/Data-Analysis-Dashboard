# Data-Analysis-Dashboard
I developed a comprehensive project in Excel, creating multiple dashboards and tables to analyze the fata. This process involved several stages, including data preprocessing, data cleaning, and data visualization.
